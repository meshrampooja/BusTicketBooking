package com.myblog.utils;

public class MainClass {
    public static void main(String[] args) {
        String name="stallin";
        long age=110;
        System.out.println(String.format("%s is your name and age is '%s'",name,age));
  }
}
